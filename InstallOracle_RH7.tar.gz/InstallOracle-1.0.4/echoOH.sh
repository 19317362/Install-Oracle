echo "$ORACLE_HOME"
